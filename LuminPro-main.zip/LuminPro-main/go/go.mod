module github.com/YuleBest/LuminPro/go

go 1.26.0

require golang.org/x/sys v0.48.0
